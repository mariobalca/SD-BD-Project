package genericclasses;

/**
 * Created by Rui on 26/10/2015.
 */
public class Ping extends Request {
    public Ping(){
        super("Ping");
    }

}
