myApp.controller('rewardController', ['$scope', '$log', '$http', function($scope, $log, $http){
}])