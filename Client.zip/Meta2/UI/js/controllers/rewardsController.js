myApp.controller('rewardsController', ['$scope', '$log', '$http', function($scope, $log, $http){
}])